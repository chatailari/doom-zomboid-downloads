package cl.nazaret.fronteradefuego;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Solo comparte temporalmente el archivo verificado con el instalador Android. */
public final class VerifiedApkProvider extends ContentProvider {
    private File verifiedFile(Uri uri) throws FileNotFoundException {
        if (getContext()==null || uri==null || !"/release.apk".equals(uri.getPath()) ||
            !((getContext().getPackageName()+".updates").equals(uri.getAuthority())))
            throw new FileNotFoundException("Archivo no autorizado");
        File f = new File(new File(getContext().getCacheDir(),"updates"),"verified.apk");
        if (!f.isFile() || f.length()==0) throw new FileNotFoundException("APK verificada no disponible");
        return f;
    }
    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) { return "/release.apk".equals(uri.getPath()) ? "application/vnd.android.package-archive" : null; }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Solo lectura");
        return ParcelFileDescriptor.open(verifiedFile(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        try {
            File f=verifiedFile(uri);
            String[] cols = projection==null ? new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor cursor=new MatrixCursor(cols);
            Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i]="FRONTERA_DE_FUEGO_actualizacion.apk";
                else if(OpenableColumns.SIZE.equals(cols[i])) row[i]=f.length();
            }
            cursor.addRow(row);
            return cursor;
        } catch(FileNotFoundException e) { return null; }
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException(); }
}
