package cl.nazaret.fronteradefuego;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.os.Build;
import android.os.Environment;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.net.Uri;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.concurrent.atomic.AtomicBoolean;

/** Lanzador nativo original. Godot se incorpora después como módulo jugable. */
public final class LauncherActivity extends Activity {
    private static final String CHANNEL = "https://raw.githubusercontent.com/chatailari/doom-zomboid-downloads/main/frontera-de-fuego/channel.json";
    private static final String RELEASE_PREFIX = "https://github.com/chatailari/doom-zomboid-downloads/releases/download/frontera-v";
    private static final int APP_CODE = 6;
    private static final long MAX_CONTENT_BYTES = 512L * 1024 * 1024;
    private final AtomicBoolean checking = new AtomicBoolean(false);
    private final AtomicBoolean downloadingApk = new AtomicBoolean(false);
    private TextView info, status;
    private Button update;
    private SharedPreferences prefs;
    private final Handler introHandler = new Handler(Looper.getMainLooper());
    private Runnable finishIntro;
    private boolean introFinished = false;
    private static final int BG = Color.rgb(12, 28, 25);
    private static final int PANEL = Color.rgb(22, 49, 43);
    private static final int ACCENT = Color.rgb(240, 184, 110);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("frontera", MODE_PRIVATE);
        // Activity recreations skip the cinematic to avoid locking a user in a loop.
        if (saved != null && saved.getBoolean("introFinished", false)) {
            introFinished = true;
            drawMenu();
        } else showIntro();
    }
    private void showIntro() {
        IntroSceneView scene = new IntroSceneView(this);
        setContentView(scene);
        finishIntro = () -> {
            if (introFinished || isFinishing()) return;
            introFinished = true;
            scene.setOnClickListener(null);
            drawMenu();
        };
        scene.setOnClickListener(v -> { introHandler.removeCallbacks(finishIntro); finishIntro.run(); });
        introHandler.postDelayed(finishIntro, 6000L);
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putBoolean("introFinished", introFinished);
        super.onSaveInstanceState(out);
    }
    @Override protected void onDestroy() {
        if (finishIntro != null) introHandler.removeCallbacks(finishIntro);
        super.onDestroy();
    }
    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable box(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(10));
        d.setStroke(dp(1), Color.rgb(132, 91, 47)); return d;
    }
    private TextView label(String s, int sp, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(sp);
        t.setPadding(dp(12), dp(9), dp(12), dp(9)); return t;
    }
    private Button button(String s, GridLayout parent, Runnable cb) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(13); b.setBackground(box(PANEL));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width=dp(169); lp.height=dp(43); lp.rightMargin=dp(5); lp.bottomMargin=dp(5);
        parent.addView(b, lp); b.setOnClickListener(v -> cb.run()); return b;
    }
    private void drawMenu() {
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(BG); main.setPadding(dp(12), dp(10), dp(12), dp(10));
        setContentView(main);
        TextView title = label("FRONTERA DE FUEGO", 29, ACCENT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        main.addView(title);
        TextView subtitle = label("CHILE · CONQUISTA · BASE ANDROID 0.1.5", 13, 0xffb6c9be);
        subtitle.setGravity(Gravity.CENTER); main.addView(subtitle);
        LinearLayout body = new LinearLayout(this);body.setOrientation(LinearLayout.HORIZONTAL);
        main.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        ScrollView navScroll = new ScrollView(this);
        GridLayout nav = new GridLayout(this);nav.setColumnCount(2);
        nav.setPadding(dp(8), dp(7), dp(8), dp(7));navScroll.setBackground(box(PANEL));navScroll.addView(nav);
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(dp(370), -1);navLp.rightMargin=dp(10);body.addView(navScroll, navLp);
        ScrollView contentScroll = new ScrollView(this);contentScroll.setBackground(box(PANEL));
        info=label("Bienvenido. Esta base conservará tus ajustes y permitirá recibir futuras versiones. El juego se agregará después.", 18, Color.WHITE);
        contentScroll.addView(info);body.addView(contentScroll,new LinearLayout.LayoutParams(0,-1,1));
        button("JUGAR",nav,()->show("JUGAR", "Motor y campañas todavía no instalados. Este lanzador no finge tener batallas disponibles."));
        button("MULTIJUGADOR",nav,()->show("MULTIJUGADOR", "Servidores y conexión se incorporarán cuando exista el juego."));
        button("ELEGIR BANDO",nav,()->chooseSide());
        button("CAMPAÑA",nav,()->show("CAMPAÑA", "1541 · Defensa de Santiago\n1553 · Tucapel\n1554 · Marigüeñu\n1557 · Mataquito\n1598 · Curalaba\n\nMisiones pendientes de contenido descargable."));
        button("CONFIGURACIÓN",nav,()->settings());
        update=button("ACTUALIZAR",nav,()->checkUpdates());
        button("HISTORIA Y CRÉDITOS",nav,()->show("HISTORIA", "Juego histórico original en desarrollo. Las reconstrucciones distinguirán hechos documentados y ficción."));
        button("SALIR",nav,()->finish());
        status=label("APK base 0.1.5 · Actualizaciones firmadas · Sin contenido jugable", 13, 0xffb0d3be);
        main.addView(status);
    }
    private void show(String title,String message){info.setText(title+"\n\n"+message);}
    private void notice(String message){runOnUiThread(()->status.setText(message));}
    private void chooseSide() {
        new AlertDialog.Builder(this).setTitle("ELEGIR BANDO")
            .setItems(new String[]{"Corona española", "Resistencia mapuche"}, (d,which)->{
                String side=which==0?"Corona española":"Resistencia mapuche";
                prefs.edit().putString("side",side).apply(); show("BANDO GUARDADO",side);
            }).show();
    }
    private void settings(){
        String q=prefs.getString("quality","Media");
        show("CONFIGURACIÓN", "Idioma: Español de Chile\nCalidad de gráficos: "+q+"\nBando: "+prefs.getString("side","Sin seleccionar"));
        new AlertDialog.Builder(this).setTitle("Calidad gráfica")
            .setItems(new String[]{"Baja","Media","Alta"},(d,i)->{
                String quality=new String[]{"Baja","Media","Alta"}[i];
                prefs.edit().putString("quality",quality).apply();settingsSummary();
            }).setNegativeButton("Cancelar",null).show();
    }
    private void settingsSummary(){show("CONFIGURACIÓN", "Calidad: "+prefs.getString("quality","Media")+"\nBando: "+prefs.getString("side","Sin seleccionar"));}
    private static byte[] fetch(String source, long limit) throws Exception {
        URL url=new URL(source);
        if(!"https".equals(url.getProtocol()))throw new IOException("Solo HTTPS");
        HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(10000);c.setReadTimeout(15000);
        c.setInstanceFollowRedirects(true);c.setRequestProperty("Accept", "application/json");
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))>=0){out.write(buf,0,n);if(out.size()>limit)throw new IOException("Archivo demasiado grande");}
            return out.toByteArray();
        }finally{c.disconnect();}
    }
    private PublicKey releaseKey() throws Exception {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        try(InputStream in=getAssets().open("update_public.pem")){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);}
        String pem=b.toString("UTF-8").replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replaceAll("\\s", "");
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(pem,Base64.DEFAULT)));
    }
    private JSONObject verifyChannel(byte[] raw) throws Exception {
        JSONObject wrapper=new JSONObject(new String(raw,"UTF-8"));
        String payload=wrapper.getString("payload");byte[] signature=Base64.decode(wrapper.getString("signature"), Base64.DEFAULT);
        Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(releaseKey());
        verifier.update(payload.getBytes("UTF-8"));
        if(!verifier.verify(signature))throw new SecurityException("Firma del canal inválida");
        JSONObject data=new JSONObject(payload);
        if(!getPackageName().equals(data.getString("package")))throw new SecurityException("Identidad del canal incorrecta");
        return data;
    }
    private static boolean approved(String url,String suffix) {
        try{
            URI u=new URI(url);
            return "https".equals(u.getScheme())&&"github.com".equals(u.getHost())&&
                url.startsWith(RELEASE_PREFIX)&&u.getRawQuery()==null&&u.getRawFragment()==null&&
                u.getPath().endsWith(suffix);
        }catch(Exception e){return false;}
    }
    private static boolean shaIsValid(String s){return s.matches("[0-9a-f]{64}");}
    private void checkUpdates(){
        if(!checking.compareAndSet(false,true))return;
        update.setEnabled(false);notice("Consultando canal oficial firmado...");
        new Thread(()->{
            try{
                JSONObject data=verifyChannel(fetch(CHANNEL,96*1024));
                int latest=data.getInt("version_code");
                if(latest>APP_CODE){
                    String url=data.getString("apk_url"); String hash=data.getString("sha256");
                    if(!approved(url,".apk")||!shaIsValid(hash))throw new SecurityException("Datos de APK no confiables");
                    runOnUiThread(()->new AlertDialog.Builder(this).setTitle("NUEVA APK DISPONIBLE")
                        .setMessage("Versión "+data.optString("version")+"\nSe descargará dentro de la aplicación, se verificará y Android te pedirá confirmar la instalación. No desinstales la app anterior.")
                        .setPositiveButton("DESCARGAR Y VERIFICAR",(d,w)->downloadVerifiedApk(url,hash))
                        .setNegativeButton("Después",null).show());
                    notice("Nueva versión de la aplicación disponible");
                }else{
                    JSONObject content=data.optJSONObject("content");
                    int c=content==null?0:content.optInt("version_code",0);
                    if(c>prefs.getInt("content_code",0) && content.optInt("required_app_code",1)<=APP_CODE){
                        String url=content.getString("url"),hash=content.getString("sha256");
                        if(!approved(url,".pck")||!shaIsValid(hash))throw new SecurityException("Contenido rechazado");
                        downloadContent(url,hash,c);
                    }else if(latest<APP_CODE){
                        notice("APK 0.1.5 instalada. El canal anuncia una versión anterior: no hay descarga nueva.");
                    }else notice("APK 0.1.5 actualizada. Contenido "+prefs.getInt("content_code",0));
                }
            }catch(Exception e){notice("Actualización no disponible: "+e.getClass().getSimpleName());}
            finally{checking.set(false);runOnUiThread(()->update.setEnabled(true));}
        },"frontera-updates").start();
    }
    /** Instala solo APK cuyo SHA-256 esté incluido en un manifiesto RSA verificado. */
    private void downloadVerifiedApk(String url, String expectedSha256) {
        if (!downloadingApk.compareAndSet(false,true)) {
            notice("Ya hay una descarga de APK en curso");
            return;
        }
        if (!approved(url, ".apk") || !shaIsValid(expectedSha256)) {
            downloadingApk.set(false);
            notice("Actualización bloqueada: URL o hash inválidos");
            return;
        }
        update.setEnabled(false);
        notice("Descargando APK oficial...");
        new Thread(() -> {
            File folder = new File(getCacheDir(), "updates");
            File partial = new File(folder, "descarga.tmp");
            File verified = new File(folder, "verified.apk");
            HttpURLConnection conn = null;
            try {
                if (!folder.exists() && !folder.mkdirs()) throw new IOException("Almacenamiento no disponible");
                if (partial.exists() && !partial.delete()) throw new IOException("No se puede limpiar descarga anterior");
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/octet-stream");
                if (conn.getResponseCode()!=HttpURLConnection.HTTP_OK) throw new IOException("HTTP "+conn.getResponseCode());
                if (!"https".equalsIgnoreCase(conn.getURL().getProtocol())) throw new SecurityException("Redirección insegura");
                long advertised = conn.getContentLengthLong();
                if (advertised > MAX_CONTENT_BYTES) throw new IOException("APK supera límite de tamaño");
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                long total = 0;
                long lastUi = 0;
                try (InputStream input = conn.getInputStream(); FileOutputStream output = new FileOutputStream(partial)) {
                    byte[] buf = new byte[65536]; int read;
                    while ((read=input.read(buf))!=-1) {
                        total += read;
                        if (total>MAX_CONTENT_BYTES) throw new IOException("APK excede 512 MB");
                        digest.update(buf,0,read);
                        output.write(buf,0,read);
                        if (total-lastUi>=1024*1024) {
                            lastUi=total;
                            notice("Descargando APK: "+(total/1024/1024)+" MB");
                        }
                    }
                    output.getFD().sync();
                }
                if (total==0 || (advertised>=0 && total!=advertised)) throw new IOException("Descarga incompleta");
                StringBuilder actual = new StringBuilder();
                for (byte b : digest.digest()) actual.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
                if (!MessageDigest.isEqual(expectedSha256.getBytes("US-ASCII"),actual.toString().getBytes("US-ASCII")))
                    throw new SecurityException("SHA-256 no coincide; no se instalará");
                if (verified.exists() && !verified.delete()) throw new IOException("No se puede sustituir APK anterior");
                if (!partial.renameTo(verified)) throw new IOException("No se puede guardar APK verificada");
                notice("APK verificada. Abriendo instalador Android...");
                runOnUiThread(() -> installVerifiedApk());
            } catch (Exception ex) {
                notice("Descarga rechazada: "+ex.getClass().getSimpleName()+". Comprueba tu conexión e intenta otra vez.");
            } finally {
                if (conn!=null) conn.disconnect();
                if (partial.exists()) partial.delete();
                downloadingApk.set(false);
                runOnUiThread(() -> { if (update!=null) update.setEnabled(true); });
            }
        }, "frontera-apk-download").start();
    }
    /** ContentProvider privado concede lectura temporal al instalador del sistema. */
    private void installVerifiedApk() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this).setTitle("PERMITIR ACTUALIZACIÓN")
                .setMessage("Android necesita autorizar la instalación desde Frontera de Fuego. Activa 'Permitir desde esta fuente' y vuelve a pulsar ACTUALIZAR; la APK ya está descargada y verificada.")
                .setPositiveButton("ABRIR AJUSTES", (d,w)->{
                    try { startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:"+getPackageName()))); }
                    catch(ActivityNotFoundException e) { notice("Abre ajustes de seguridad y permite instalar desde esta aplicación"); }
                }).setNegativeButton("Después",null).show();
            return;
        }
        File apk = new File(new File(getCacheDir(), "updates"), "verified.apk");
        if (!apk.isFile() || apk.length()==0) { notice("No hay APK verificada. Pulsa ACTUALIZAR otra vez."); return; }
        Uri contentUri = Uri.parse("content://"+getPackageName()+".updates/release.apk");
        Intent install = new Intent(Intent.ACTION_VIEW);
        install.setDataAndType(contentUri,"application/vnd.android.package-archive");
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(install); }
        catch (ActivityNotFoundException e) { notice("No se encontró el instalador APK de Android"); }
        catch (SecurityException e) { notice("Android bloqueó la instalación. Comprueba permisos de esta aplicación."); }
    }
    private void downloadContent(String url,String expected,int code) throws Exception {
        File dir=new File(getFilesDir(),"content");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Sin almacenamiento");
        File tmp=new File(dir,"package.tmp"), out=new File(dir,"content_"+code+".pck");
        MessageDigest sha=MessageDigest.getInstance("SHA-256");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setReadTimeout(20000);c.setConnectTimeout(10000);
        long size=0;
        try(InputStream in=c.getInputStream();FileOutputStream fos=new FileOutputStream(tmp)){
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            byte[] b=new byte[8192];int n;
            while((n=in.read(b))!=-1){size+=n;if(size>MAX_CONTENT_BYTES)throw new IOException("Contenido demasiado grande");sha.update(b,0,n);fos.write(b,0,n);}
            fos.getFD().sync();
            StringBuilder h=new StringBuilder();for(byte x:sha.digest())h.append(String.format(java.util.Locale.ROOT,"%02x", x&255));
            if(!expected.equals(h.toString()))throw new SecurityException("SHA-256 del contenido incorrecto");
            if(!tmp.renameTo(out))throw new IOException("No se pudo activar contenido");
            prefs.edit().putInt("content_code",code).apply();
            notice("Contenido "+code+" descargado y verificado. El motor lo incorporará cuando esté instalado.");
        }finally{c.disconnect();if(tmp.exists())tmp.delete();}
    }
}
