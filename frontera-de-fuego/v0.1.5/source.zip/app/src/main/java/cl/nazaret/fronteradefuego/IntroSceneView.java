package cl.nazaret.fronteradefuego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

/** Apertura animada original, sin dependencias, vídeos remotos ni descargas automáticas. */
final class IntroSceneView extends View {
    private final Bitmap backdrop;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final long startMillis = SystemClock.uptimeMillis();
    private final Rect bitmapRect = new Rect();
    private final RectF screenRect = new RectF();

    IntroSceneView(Context context) {
        super(context);
        Bitmap loaded = null;
        try (java.io.InputStream f = context.getAssets().open("intro_calle_chile.jpg")) {
            loaded = BitmapFactory.decodeStream(f);
        } catch (java.io.IOException ignored) { }
        backdrop = loaded;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        final float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float seconds = (SystemClock.uptimeMillis() - startMillis) / 1000f;
        c.save();
        c.scale(w / 1280f, h / 720f);
        p.setAlpha(255); p.setColor(Color.WHITE);
        c.drawColor(Color.rgb(22, 22, 20));
        if (backdrop != null) {
            // Panorámica lenta: el ejército parece avanzar mientras la cámara lo acompaña.
            int drift = Math.min(48, (int)(seconds * 7));
            bitmapRect.set(drift, 0, Math.max(drift + 1, backdrop.getWidth() - 18), backdrop.getHeight());
            screenRect.set(0, 0, 1280, 720);
            c.drawBitmap(backdrop, bitmapRect, screenRect, p);
        }
        // Pequeña patrulla animada en primer plano. Se desplaza de izquierda a derecha.
        for (int i = 0; i < 4; i++) {
            float x = 140 + (i * 76) + seconds * 29;
            float y = 614 + (i % 2) * 16 + (float)Math.sin(seconds * 7 + i) * 4;
            drawSoldier(c, x, y, i == 0 ? 1.05f : .9f);
        }
        // Siluetas mapuches en la distancia. No son un ejército español de primer plano.
        for (int i = 0; i < 7; i++) {
            float sway = (float)Math.sin(seconds * 1.8 + i * 2.2) * 1.2f;
            drawDistantMapuche(c, 985 + i * 37 + sway, 477 + (i%3)*5, 0.48f + (i%2)*0.07f);
        }
        // Oscurecimiento inferior para que el texto sea legible.
        p.setColor(Color.argb(145, 8, 7, 8));
        c.drawRect(0, 620, 1280, 720, p);
        p.setTypeface(Typeface.create("serif", Typeface.BOLD));
        p.setColor(Color.rgb(255, 223, 169)); p.setTextSize(42);
        c.drawText("FRONTERA DE FUEGO", 33, 672, p);
        p.setColor(Color.rgb(228, 230, 224)); p.setTextSize(22);
        c.drawText("Chile, siglo XVI  ·  Reconstrucción artística", 35, 701, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(18);
        c.drawText("TOCA PARA CONTINUAR", 1010, 694, p);
        c.restore();
        if (seconds < 6.6f) postInvalidateDelayed(32);
    }

    private void drawDistantMapuche(Canvas canvas, float x, float y, float scale) {
        canvas.save(); canvas.translate(x,y); canvas.scale(scale,scale);
        // Traje simple de tejido oscuro, pelo largo y lanza.
        p.setColor(Color.rgb(35,27,20)); p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(5);
        canvas.drawLine(-4,0,-13,40,p); canvas.drawLine(5,0,15,40,p);
        p.setColor(Color.rgb(53,39,30)); canvas.drawRoundRect(-14,-35,14,5,3,3,p);
        p.setColor(Color.rgb(33,22,17)); canvas.drawCircle(0,-46,12,p);
        p.setColor(Color.rgb(157,133,93)); p.setStrokeWidth(4);
        canvas.drawLine(20,-93,22,32,p);
        p.setColor(Color.rgb(18,14,12)); canvas.drawLine(-10,-57,11,-57,p);
        canvas.restore();
    }

    private void drawSoldier(Canvas canvas, float x, float y, float scale) {
        canvas.save();canvas.translate(x, y);canvas.scale(scale, scale);
        p.setColor(Color.argb(225, 26, 24, 21));
        // Pasos alternados para dar sensación real de marcha.
        float phase = (SystemClock.uptimeMillis() - startMillis) / 120f + x / 31f;
        float step = (float)Math.sin(phase) * 6;
        p.setStrokeWidth(8); p.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawLine(0, 3, -12 + step, 38, p);
        canvas.drawLine(0, 3, 11 - step, 39, p);
        canvas.drawRoundRect(-17, -42, 16, 7, 5, 5, p);
        canvas.drawCircle(1, -55, 12, p);
        canvas.drawOval(-20, -70, 21, -63, p); // casco
        p.setStrokeWidth(3);canvas.drawLine(24, -101, 24, 12, p); // lanza
        canvas.restore();
    }
}
