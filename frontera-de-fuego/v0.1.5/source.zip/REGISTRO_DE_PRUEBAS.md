# Frontera de Fuego 0.1.5 | registro de pruebas (2026-11-01)

**Estado:** candidata con fuente, recursos, prueba estática y claves de referencia verificadas. **No es APK ni actualización publicada.**

## Resultados demostrados
- `scripts/verify_source.py`: PASS; package `cl.nazaret.fronteradefuego`, `versionCode=6`, icono PNG, intro JPG, `IntroSceneView`, transición 6 segundos, preservación del verificador RSA, ausencia de claves privadas en árbol fuente.
- Manifesto público firmado 0.1.4: PASS, verificación criptográfica `SHA256withRSA` con `app/src/main/assets/update_public.pem`.
- Clave privada RSA histórica y clave pública embebida: PASS, pareja coincidente; la clave privada NO está en este ZIP.
- Keystore Android histórico PKCS12: PASS, alias `frontera`, huella SHA256 `823D6F6C52A5D47D6FD8D1A16A1D6447E98C19FA938427A90734B1CFB3A70EA0`.
- `FRONTERA_NATIVE_0_1_4_RELEASE.zip`: `jarsigner -verify` PASS; certificado autofirmado original (advertencia normal, no cadena pública de CA).
- Apertura sin repetición: se agregó `onSaveInstanceState` para saltar introducción tras recreación.
- Se corrigió arte ilustrativo: icono con personaje mapuche sin atuendo azteca, panorámica sin bandera moderna española en primer plano, grupo mapuche animado dibujado en distancia.

## NO demostrado
- Compilación Android 0.1.5: entorno local carece de Android SDK, Gradle y red de descarga.
- APK 0.1.5 firmada, instalación física y upgrade directo 0.1.4 -> 0.1.5: NO realizados.
- Publicación de release 0.1.5 y manifiesto RSA 0.1.5: NO realizados.

## Regla de publicación
1. Ejecutar `ci/build-frontera-v015.yml` en el repo de distribución donde se suba `frontera-de-fuego/v0.1.5/source.zip`, con secrets seguros para firma original.
2. Verificar APK generada: paquete, versión 6, certificado original, SHA256 real, menú e intro en Android 14.
3. Probar instalación sobre 0.1.4 SIN desinstalar y preservar preferencias.
4. Solo después de ello generar manifiesto con firma RSA y actualizar `frontera-de-fuego/channel.json` a 0.1.5. NO comprometer claves privadas.

Repositorio de distribución: `chatailari/doom-zomboid-downloads`. Canal de producción conservado en v0.1.4.
