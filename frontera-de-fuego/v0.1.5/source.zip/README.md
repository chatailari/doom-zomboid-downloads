# FRONTERA DE FUEGO 0.1.5 | Android nativo | CANDIDATO

Versión conservadora sobre 0.1.4, identidad `cl.nazaret.fronteradefuego`, versionCode 6, firma y clave pública RSA del canal intactas.

## Nuevos recursos
- Icono del lanzador: encuentro entre conquistador español y guerrero mapuche. No se representa como recreación documental exacta.
- Pantalla de apertura de seis segundos: calle de tierra, españoles marchando, grupo mapuche a distancia. Se omite al tocar y no se reinicia de forma innecesaria ante recreación de Activity.
- Menú y verificación de actualizaciones conservados: canal HTTPS con manifiesto RSA; la aplicación 0.1.4 detectará esta APK cuando se publique un manifiesto correcto.

## Construcción para Linux en CI
Requiere Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.1 y Android SDK 35.
Ejecutar `gradle :app:assembleRelease`.
Firmar **fuera del repositorio** mediante el certificado original con `apksigner` v2/v3; verificar fingerprint SHA256 de firma de Android:
`823D6F6C52A5D47D6FD8D1A16A1D6447E98C19FA938427A90734B1CFB3A70EA0`.
La clave y contraseña nunca deben subirse a GitHub ni incluirse en artefactos.

## Política de publicación
No modificar `frontera-de-fuego/channel.json` del repositorio público hasta que una APK 0.1.5 verdaderamente firmada esté accesible, su SHA256 esté confirmado y se valide la actualización sobre 0.1.4 sin perder datos. El canal actual se conserva en 0.1.4.

Nota: la primera instalación actualiza mediante APK completa, no mediante PCK. El motor Godot se incorporará después. Los recursos históricos son ilustraciones y no una reconstrucción arqueológica certificada.


## Corrección real del botón ACTUALIZAR (fase 0.1.5)
- El lanzador ya no manda a navegador: descarga la APK en caché de la aplicación (HTTPS).
- Valida un canal firmado RSA SHA-256 antes de admitir la URL, verifica SHA-256 del paquete completo y límite de 512 MB.
- No abre el instalador Android hasta validar el hash. Usa un ContentProvider interno de solo lectura y permiso temporal.
- Para Android 8+, muestra permiso para instalar desde esta fuente cuando corresponde.
- Android solicitará confirmación: ninguna aplicación puede instalar una APK común silenciosamente sin privilegios de sistema.
- La 0.1.4 existente conserva su botón anterior y detectará 0.1.5 solo al publicar un manifiesto nuevo firmado. Desde 0.1.5 las siguientes APK se descargan dentro de la propia app.

**NO publicar** el canal 0.1.5 sin APK firmada con la clave original y prueba de instalación encima de 0.1.4.
