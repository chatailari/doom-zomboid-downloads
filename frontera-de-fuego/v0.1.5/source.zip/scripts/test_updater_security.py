#!/usr/bin/env python3
"""Comprobación de propiedades críticas del actualizador, sin simular una instalación Android."""
from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_source import p
launcher=(p/'app/src/main/java/cl/nazaret/fronteradefuego/LauncherActivity.java').read_text()
provider=(p/'app/src/main/java/cl/nazaret/fronteradefuego/VerifiedApkProvider.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
assert 'downloadVerifiedApk(url,hash)' in launcher
assert 'startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)))' not in launcher, 'Descarga por navegador no permitida'
assert 'verifyChannel(fetch(CHANNEL' in launcher and 'SHA256withRSA' in launcher
assert 'MessageDigest.isEqual(' in launcher and 'MAX_CONTENT_BYTES' in launcher
assert 'renameTo(verified)' in launcher and 'FLAG_GRANT_READ_URI_PERMISSION' in launcher
assert 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' in launcher
assert 'android.permission.REQUEST_INSTALL_PACKAGES' in manifest
assert 'android:exported="false"' in manifest and 'android:grantUriPermissions="true"' in manifest
assert 'ParcelFileDescriptor.MODE_READ_ONLY' in provider and '"r".equals(mode)' in provider
assert '"/release.apk".equals(uri.getPath())' in provider
assert 'versionCode 6' in (p/'app/build.gradle').read_text()
print('PASS: descarga en-app, manifiesto RSA, hash SHA-256, proveedor privado, permiso y versionCode')
