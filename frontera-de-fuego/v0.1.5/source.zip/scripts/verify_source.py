from pathlib import Path
import zipfile
p = Path(__file__).resolve().parents[1]
main = (p / 'app/src/main/java/cl/nazaret/fronteradefuego/LauncherActivity.java').read_text()
intro = (p / 'app/src/main/java/cl/nazaret/fronteradefuego/IntroSceneView.java').read_text()
b = (p / 'app/build.gradle').read_text()
manifest = (p / 'app/src/main/AndroidManifest.xml').read_text()
assert 'cl.nazaret.fronteradefuego' in b and 'versionCode 6' in b and "versionName '0.1.5'" in b
assert 'APP_CODE = 6' in main and 'SHA256withRSA' in main and 'verifyChannel(fetch(' in main
assert 'introHandler.postDelayed(finishIntro, 6000L)' in main and 'onSaveInstanceState' in main
assert 'drawSoldier(' in intro and 'drawDistantMapuche(' in intro and 'postInvalidateDelayed(32)' in intro
assert 'android:icon="@drawable/frontera_icon"' in manifest
assert (p / 'app/src/main/res/drawable-nodpi/frontera_icon.png').read_bytes()[:8] == b'\x89PNG\r\n\x1a\n'
assert (p / 'app/src/main/assets/intro_calle_chile.jpg').read_bytes()[:2] == b'\xff\xd8'
assert (p / 'app/src/main/assets/update_public.pem').read_text().startswith('-----BEGIN PUBLIC KEY-----')
for f in p.rglob('*'):
    if f.is_file():
        assert f.suffix.lower() not in ('.p12', '.jks', '.keystore'), f
        if f.suffix.lower() in ('.java', '.py', '.gradle', '.md'):
            assert ('-----BEGIN ' + 'PRIVATE KEY-----') not in f.read_text(), f
print('PASS: source v0.1.5, versionCode, intro, actualizador y exclusión de secretos')
