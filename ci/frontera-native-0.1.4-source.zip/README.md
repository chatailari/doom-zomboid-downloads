# FRONTERA DE FUEGO 0.1.4 (EXPERIMENTO NATIVO)

Base Android Java sin dependencias de Godot para los menus. NO PUBLICAR como reemplazo del APK hasta pruebas reales.

Mismo package `cl.nazaret.fronteradefuego`, `versionCode=5`. Requiere firmar con certificado original fuera del repositorio. Codigo fuente NO contiene claves privadas.

La base comprueba RSA SHA-256 sobre canal HTTPS firmado, permite actualizar la APK con consentimiento de Android, guarda ajustes, y descarga paquetes `.pck` verificados SHA-256 al almacenamiento privado; aun NO ejecuta Godot ni contiene misiones.

Para futuros juegos/aplicaciones: duplicar fuente y asignar package, certificado y canal independientes. No usar esta APK como instalador universal de paquetes ajenos.
