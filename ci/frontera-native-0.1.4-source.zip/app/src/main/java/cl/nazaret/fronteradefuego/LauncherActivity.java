package cl.nazaret.fronteradefuego;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.StrictMode;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.concurrent.atomic.AtomicBoolean;

/** Lanzador nativo original. Godot se incorpora después como módulo jugable. */
public final class LauncherActivity extends Activity {
    private static final String CHANNEL = "https://raw.githubusercontent.com/chatailari/doom-zomboid-downloads/main/frontera-de-fuego/channel.json";
    private static final String RELEASE_PREFIX = "https://github.com/chatailari/doom-zomboid-downloads/releases/download/frontera-v";
    private static final int APP_CODE = 5;
    private static final long MAX_CONTENT_BYTES = 512L * 1024 * 1024;
    private final AtomicBoolean checking = new AtomicBoolean(false);
    private TextView info, status;
    private Button update;
    private SharedPreferences prefs;
    private static final int BG = Color.rgb(12, 28, 25);
    private static final int PANEL = Color.rgb(22, 49, 43);
    private static final int ACCENT = Color.rgb(240, 184, 110);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("frontera", MODE_PRIVATE);
        drawMenu();
    }
    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable box(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(10));
        d.setStroke(dp(1), Color.rgb(132, 91, 47)); return d;
    }
    private TextView label(String s, int sp, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(sp);
        t.setPadding(dp(12), dp(9), dp(12), dp(9)); return t;
    }
    private Button button(String s, LinearLayout parent, Runnable cb) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(15); b.setBackground(box(PANEL));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(47)); lp.bottomMargin = dp(7);
        parent.addView(b, lp); b.setOnClickListener(v -> cb.run()); return b;
    }
    private void drawMenu() {
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(BG); main.setPadding(dp(12), dp(10), dp(12), dp(10));
        setContentView(main);
        TextView title = label("FRONTERA DE FUEGO", 29, ACCENT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        main.addView(title);
        TextView subtitle = label("CHILE · CONQUISTA · BASE ANDROID 0.1.4", 13, 0xffb6c9be);
        subtitle.setGravity(Gravity.CENTER); main.addView(subtitle);
        LinearLayout body = new LinearLayout(this);body.setOrientation(LinearLayout.HORIZONTAL);
        main.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        ScrollView navScroll = new ScrollView(this);
        LinearLayout nav = new LinearLayout(this);nav.setOrientation(LinearLayout.VERTICAL);
        nav.setPadding(dp(8), dp(7), dp(8), dp(7));navScroll.setBackground(box(PANEL));navScroll.addView(nav);
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(dp(215), -1);navLp.rightMargin=dp(10);body.addView(navScroll, navLp);
        ScrollView contentScroll = new ScrollView(this);contentScroll.setBackground(box(PANEL));
        info=label("Bienvenido. Esta base conservará tus ajustes y permitirá recibir futuras versiones. El juego se agregará después.", 18, Color.WHITE);
        contentScroll.addView(info);body.addView(contentScroll,new LinearLayout.LayoutParams(0,-1,1));
        button("JUGAR",nav,()->show("JUGAR", "Motor y campañas todavía no instalados. Este lanzador no finge tener batallas disponibles."));
        button("MULTIJUGADOR",nav,()->show("MULTIJUGADOR", "Servidores y conexión se incorporarán cuando exista el juego."));
        button("ELEGIR BANDO",nav,()->chooseSide());
        button("CAMPAÑA",nav,()->show("CAMPAÑA", "1541 · Defensa de Santiago\n1553 · Tucapel\n1554 · Marigüeñu\n1557 · Mataquito\n1598 · Curalaba\n\nMisiones pendientes de contenido descargable."));
        button("CONFIGURACIÓN",nav,()->settings());
        update=button("ACTUALIZAR",nav,()->checkUpdates());
        button("HISTORIA Y CRÉDITOS",nav,()->show("HISTORIA", "Juego histórico original en desarrollo. Las reconstrucciones distinguirán hechos documentados y ficción."));
        button("SALIR",nav,()->finish());
        status=label("APK base 0.1.4 · Actualizaciones firmadas · Sin contenido jugable", 13, 0xffb0d3be);
        main.addView(status);
    }
    private void show(String title,String message){info.setText(title+"\n\n"+message);}
    private void notice(String message){runOnUiThread(()->status.setText(message));}
    private void chooseSide() {
        new AlertDialog.Builder(this).setTitle("ELEGIR BANDO")
            .setItems(new String[]{"Corona española", "Resistencia mapuche"}, (d,which)->{
                String side=which==0?"Corona española":"Resistencia mapuche";
                prefs.edit().putString("side",side).apply(); show("BANDO GUARDADO",side);
            }).show();
    }
    private void settings(){
        String q=prefs.getString("quality","Media");
        show("CONFIGURACIÓN", "Idioma: Español de Chile\nCalidad de gráficos: "+q+"\nBando: "+prefs.getString("side","Sin seleccionar"));
        new AlertDialog.Builder(this).setTitle("Calidad gráfica")
            .setItems(new String[]{"Baja","Media","Alta"},(d,i)->{
                String quality=new String[]{"Baja","Media","Alta"}[i];
                prefs.edit().putString("quality",quality).apply();settingsSummary();
            }).setNegativeButton("Cancelar",null).show();
    }
    private void settingsSummary(){show("CONFIGURACIÓN", "Calidad: "+prefs.getString("quality","Media")+"\nBando: "+prefs.getString("side","Sin seleccionar"));}
    private static byte[] fetch(String source, long limit) throws Exception {
        URL url=new URL(source);
        if(!"https".equals(url.getProtocol()))throw new IOException("Solo HTTPS");
        HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(10000);c.setReadTimeout(15000);
        c.setInstanceFollowRedirects(true);c.setRequestProperty("Accept", "application/json");
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))>=0){out.write(buf,0,n);if(out.size()>limit)throw new IOException("Archivo demasiado grande");}
            return out.toByteArray();
        }finally{c.disconnect();}
    }
    private PublicKey releaseKey() throws Exception {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        try(InputStream in=getAssets().open("update_public.pem")){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);}
        String pem=b.toString("UTF-8").replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replaceAll("\\s", "");
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(pem,Base64.DEFAULT)));
    }
    private JSONObject verifyChannel(byte[] raw) throws Exception {
        JSONObject wrapper=new JSONObject(new String(raw,"UTF-8"));
        String payload=wrapper.getString("payload");byte[] signature=Base64.decode(wrapper.getString("signature"), Base64.DEFAULT);
        Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(releaseKey());
        verifier.update(payload.getBytes("UTF-8"));
        if(!verifier.verify(signature))throw new SecurityException("Firma del canal inválida");
        JSONObject data=new JSONObject(payload);
        if(!getPackageName().equals(data.getString("package")))throw new SecurityException("Identidad del canal incorrecta");
        return data;
    }
    private static boolean approved(String url,String suffix) {
        try{
            URI u=new URI(url);
            return "https".equals(u.getScheme())&&"github.com".equals(u.getHost())&&
                url.startsWith(RELEASE_PREFIX)&&u.getRawQuery()==null&&u.getRawFragment()==null&&
                u.getPath().endsWith(suffix);
        }catch(Exception e){return false;}
    }
    private static boolean shaIsValid(String s){return s.matches("[0-9a-f]{64}");}
    private void checkUpdates(){
        if(!checking.compareAndSet(false,true))return;
        update.setEnabled(false);notice("Consultando canal oficial firmado...");
        new Thread(()->{
            try{
                JSONObject data=verifyChannel(fetch(CHANNEL,96*1024));
                int latest=data.getInt("version_code");
                if(latest>APP_CODE){
                    String url=data.getString("apk_url"); String hash=data.getString("sha256");
                    if(!approved(url,".apk")||!shaIsValid(hash))throw new SecurityException("Datos de APK no confiables");
                    runOnUiThread(()->new AlertDialog.Builder(this).setTitle("NUEVA APK DISPONIBLE")
                        .setMessage("Versión "+data.optString("version")+"\nAndroid te pedirá confirmar la instalación. No desinstales la app anterior.")
                        .setPositiveButton("DESCARGAR APK",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))))
                        .setNegativeButton("Después",null).show());
                    notice("Nueva versión de la aplicación disponible");
                }else{
                    JSONObject content=data.optJSONObject("content");
                    int c=content==null?0:content.optInt("version_code",0);
                    if(c>prefs.getInt("content_code",0) && content.optInt("required_app_code",1)<=APP_CODE){
                        String url=content.getString("url"),hash=content.getString("sha256");
                        if(!approved(url,".pck")||!shaIsValid(hash))throw new SecurityException("Contenido rechazado");
                        downloadContent(url,hash,c);
                    }else if(latest<APP_CODE){
                        notice("APK 0.1.4 instalada. El canal anuncia una versión anterior: no hay descarga nueva.");
                    }else notice("APK 0.1.4 actualizada. Contenido "+prefs.getInt("content_code",0));
                }
            }catch(Exception e){notice("Actualización no disponible: "+e.getClass().getSimpleName());}
            finally{checking.set(false);runOnUiThread(()->update.setEnabled(true));}
        },"frontera-updates").start();
    }
    private void downloadContent(String url,String expected,int code) throws Exception {
        File dir=new File(getFilesDir(),"content");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Sin almacenamiento");
        File tmp=new File(dir,"package.tmp"), out=new File(dir,"content_"+code+".pck");
        MessageDigest sha=MessageDigest.getInstance("SHA-256");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setReadTimeout(20000);c.setConnectTimeout(10000);
        long size=0;
        try(InputStream in=c.getInputStream();FileOutputStream fos=new FileOutputStream(tmp)){
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            byte[] b=new byte[8192];int n;
            while((n=in.read(b))!=-1){size+=n;if(size>MAX_CONTENT_BYTES)throw new IOException("Contenido demasiado grande");sha.update(b,0,n);fos.write(b,0,n);}
            fos.getFD().sync();
            StringBuilder h=new StringBuilder();for(byte x:sha.digest())h.append(String.format(java.util.Locale.ROOT,"%02x", x&255));
            if(!expected.equals(h.toString()))throw new SecurityException("SHA-256 del contenido incorrecto");
            if(!tmp.renameTo(out))throw new IOException("No se pudo activar contenido");
            prefs.edit().putInt("content_code",code).apply();
            notice("Contenido "+code+" descargado y verificado. El motor lo incorporará cuando esté instalado.");
        }finally{c.disconnect();if(tmp.exists())tmp.delete();}
    }
}
