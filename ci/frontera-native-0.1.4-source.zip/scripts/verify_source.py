from pathlib import Path
p=Path(__file__).resolve().parents[1]
a=(p/'app/src/main/java/cl/nazaret/fronteradefuego/LauncherActivity.java').read_text()
b=(p/'app/build.gradle').read_text()
assert 'cl.nazaret.fronteradefuego' in b and 'versionCode 5' in b
assert 'SHA256withRSA' in a and 'verifyChannel(fetch(' in a
assert 'MAX_CONTENT_BYTES' in a and 'downloadContent(' in a
assert 'startActivity(new Intent(Intent.ACTION_VIEW' in a
assert not any(q in a for q in ['BEGIN PRIVATE KEY','password="','password ='])
assert (p/'app/src/main/assets/update_public.pem').read_text().startswith('-----BEGIN PUBLIC KEY-----')
print('PASS: APK nativa 0.1.4, canal firmado, limites y sin secretos')
