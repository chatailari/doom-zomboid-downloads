#!/usr/bin/env python3
"""Crea canales de actualización verificables para aplicaciones Godot.

NO publica en GitHub y NO distribuye claves privadas.
El archivo generado requiere que la APK / PCK referenciada exista en la URL
antes de activar el canal remoto.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def trusted_release_url(url, prefix, extension):
    parsed=urlparse(url)
    trusted=urlparse(prefix)
    if (parsed.scheme != 'https' or parsed.hostname != trusted.hostname or
        parsed.username or parsed.password or parsed.fragment or parsed.query or
        not parsed.path.endswith(extension) or not url.startswith(prefix)):
        raise ValueError('URL no aprobada para ' + extension)
    return url


def make_payload(package, app_code, version, apk_file, apk_url, content_code=0,
                 content_file=None, content_url='', required_app_code=1,notes='', release_prefix=''):
    if app_code < 1 or content_code < 0 or required_app_code < 1:
        raise ValueError('Versiones deben ser enteros positivos o cero para contenido')
    if content_code and (not content_file or not content_url):
        raise ValueError('Contenido versionado exige PCK y URL')
    if content_code == 0 and (content_file or content_url):
        raise ValueError('Contenido sin versión debe estar vacío')
    if not package or not version or not release_prefix:
        raise ValueError('Configuración de identidad requerida')
    data={'package':package,'version_code':app_code,'version':version,
          'apk_url':trusted_release_url(apk_url,release_prefix,'.apk'),
          'sha256':sha256(apk_file),'notes':notes,
          'content':{'version_code':content_code,'url':'','sha256':'',
                     'required_app_code':required_app_code}}
    if content_code:
        data['content']['url']=trusted_release_url(content_url,release_prefix,'.pck')
        data['content']['sha256']=sha256(content_file)
    return data


def sign(data, private_key_pem):
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':'))
    key=serialization.load_pem_private_key(Path(private_key_pem).read_bytes(),password=None)
    sig=key.sign(payload.encode('utf-8'),padding.PKCS1v15(),hashes.SHA256())
    return {'payload':payload,'signature':base64.b64encode(sig).decode('ascii')}


def verify(channel,public_key_pem,package):
    if not isinstance(channel,dict) or not isinstance(channel.get('payload'),str) or not isinstance(channel.get('signature'),str):
        raise ValueError('Sobre firmado incorrecto')
    public=serialization.load_pem_public_key(Path(public_key_pem).read_bytes())
    public.verify(base64.b64decode(channel['signature'],validate=True),
                  channel['payload'].encode('utf-8'),padding.PKCS1v15(),hashes.SHA256())
    payload=json.loads(channel['payload'])
    if payload.get('package')!=package:raise ValueError('Aplicación incorrecta')
    return payload


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--package',required=True)
    ap.add_argument('--app-code',type=int,required=True)
    ap.add_argument('--version',required=True)
    ap.add_argument('--apk',required=True)
    ap.add_argument('--apk-url',required=True)
    ap.add_argument('--content-code',type=int,default=0)
    ap.add_argument('--content-pck')
    ap.add_argument('--content-url',default='')
    ap.add_argument('--required-app-code',type=int,default=1)
    ap.add_argument('--notes',default='')
    ap.add_argument('--release-prefix',required=True)
    ap.add_argument('--private-key',required=True)
    ap.add_argument('--public-key',required=True)
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    data=make_payload(args.package,args.app_code,args.version,args.apk,args.apk_url,
                      args.content_code,args.content_pck,args.content_url,
                      args.required_app_code,args.notes,args.release_prefix)
    channel=sign(data,args.private_key)
    assert verify(channel,args.public_key,args.package)==data
    Path(args.output).write_text(json.dumps(channel,ensure_ascii=False,indent=2)+'\n')
    print('Firmado y verificado:',args.output,'(NO PUBLICADO)')


if __name__=='__main__':main()
