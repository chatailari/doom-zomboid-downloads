#!/usr/bin/env python3
"""Bloquea entregas que excluyan la clave publica del actualizador.

No equivale a ejecutar el APK en Android real.
"""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

EXPECTED = 'assets/assets/update_public.pem'

def verify(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        corruption = z.testzip()
        if corruption:
            raise AssertionError('APK ZIP corrupto: ' + corruption)
        if EXPECTED not in z.namelist():
            raise AssertionError('APK sin PEM publico para verificar actualizaciones: ' + EXPECTED)
        if b'BEGIN PUBLIC KEY' not in z.read(EXPECTED):
            raise AssertionError('PEM no parece una clave publica valida')
        if 'assets/project.binary' not in z.namelist():
            raise AssertionError('Falta proyecto Godot')
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'status':'PASS', 'apk':str(path), 'sha256':sha, 'pem':EXPECTED}

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Uso: python tests_export_apk.py ruta.apk')
    print(json.dumps(verify(Path(sys.argv[1])),indent=2))
