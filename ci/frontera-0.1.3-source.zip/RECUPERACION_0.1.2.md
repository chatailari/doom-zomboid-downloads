# FRONTERA DE FUEGO | Continuidad 0.1.2 candidata

Estado: **código fuente candidato, NO una APK compilada**.

- Se recuperó el proyecto 0.1.0 original y se conservaron APK 0.1.0/0.1.1 sin cambios.
- También se recuperaron y comprobaron aparte las claves originales: Android PKCS12 y firma RSA del manifiesto. **NO van incluidas en esta entrega**.
- Esta rama deriva de fuente 0.1.0; no reemplaza ni dice contener la fuente exacta de la versión 0.1.1.
- La versión candidata es 0.1.2 (versionCode 3) con el mismo package ID y preparada para firmar con el certificado original.
- Se corrigió la exportación del PEM público y el canal JSON, archivo no recurso que Godot omite por defecto.
- Se declararon seis estados referenciados por menu.gd que faltaban en el respaldo 0.1.0.
- Se añadieron trazas de inicio para diagnosticar en `adb logcat` el arranque y el renderizado Android.
- Se añade un gate post-compilación que rechaza una APK que carezca del PEM. No se asume que copiar el PEM arregle por sí solo la pantalla gris.
- Se mantiene el canal remoto anterior sin editar; NO anunciar un binario que no esté publicado y verificado.

## Para compilar y liberar

1. Recuperar un entorno Godot 4.5.1 estable con plantillas Android de la misma versión, Java 17, Android SDK 35.
2. Configurar localmente el keystore **original** sin adjuntarlo al repositorio y sin mostrar la contraseña.
3. Ejecutar `python3 tests_manifest.py` y `python3 tests_recuperacion.py`.
4. Compilar con el preset Android ARM64; ejecutar `python3 tests_export_apk.py build/FRONTERA-DE-FUEGO-0.1.2-arm64.apk`.
5. Comprobar firma v2/v3 del APK con `apksigner verify --print-certs`, comparando huella SHA256 `823d6f6c52a5d47d6fd8d1a16a1d6447e98c19fa938427a90734b1cfb3a70ea0`.
6. Probar instalación **sobre** 0.1.1 (sin desinstalar), renderizado, botones, persistencia y comportamiento de fallos en teléfono Android físico y emulador; guardar `adb logcat` y capturas.
7. Publicar APK solo después de pasar pruebas; firmar manifiesto con clave RSA original en entorno seguro; comprobar SHA-256 de URL oficial HTTPS antes de activar canal `main/frontera-de-fuego/channel.json`.

**Cuidado**: el botón ACTUALIZAR para APK sigue abriendo la descarga oficial en navegador y requiere consentimiento de instalación de Android; la actualización incremental desde un APK no está implementada. Para contenidos PCK existe un mecanismo separado, aún sin prueba real de actualización.
