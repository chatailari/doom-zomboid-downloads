import base64, json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
j=json.loads(Path('releases/channel.json').read_text())
pub=serialization.load_pem_public_key(Path('assets/update_public.pem').read_bytes())
import hashlib
pub.verify(base64.b64decode(j['signature']),hashlib.sha256(j['payload'].encode()).digest(),padding.PKCS1v15(),Prehashed(hashes.SHA256()))
p=json.loads(j['payload']);assert p['package']=='cl.nazaret.fronteradefuego' and p['version_code']==1
assert p['content']['version_code']==0
assert Path('scripts/menu.gd').read_text().count('CHANNEL_URL')>=1
print('PASS: firma RSA, versión, paquete y código de actualización')
