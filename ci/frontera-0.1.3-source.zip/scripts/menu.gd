extends Control

const APP_VERSION := "0.1.3"
const APP_CODE := 4
const APP_PACKAGE := "cl.nazaret.fronteradefuego"
const CHANNEL_URL := "https://raw.githubusercontent.com/chatailari/doom-zomboid-downloads/main/frontera-de-fuego/channel.json"
const TRUSTED_RELEASE_PREFIX := "https://github.com/chatailari/doom-zomboid-downloads/releases/download/frontera-v"
const DEFAULT_HOST := ""
const CONTENT_SCENE := "res://content/start.tscn"
const CONTENT_META := "user://content/verified_manifest.json"
const CONTENT_DIR := "user://content"
const CONTENT_PREFIX := "frontera_content_"
const MAX_CONTENT_BYTES := 512 * 1024 * 1024 # límite de paquete individual


var selected_side := "Sin seleccionar"
var selected_quality := "Media"
var selected_sensitivity := 1.0
var selected_music := true
var server_address := ""
var menu_panel: PanelContainer
var content_panel: PanelContainer
var main_buttons: VBoxContainer
var title_label: Label
var status: Label
var http: HTTPRequest
var update_button: Button
var pending_release_url := ""
var update_in_progress := false
# Estados usados por el actualizador y el cargador de paquetes PCK.
# En el respaldo 0.1.0 estaban referenciados sin declarar.
var content_ready := false
var content_version := 0
var update_phase := "idle"
var pending_envelope: Dictionary = {}
var pending_content: Dictionary = {}
var incoming_pack_path := ""

func _ready() -> void:
    _load_preferences()
    print("FRONTERA: inicio, version=", APP_VERSION, " render=", ProjectSettings.get_setting("rendering/renderer/rendering_method", "desconocido"))
    _render_shell()
    print("FRONTERA: interfaz construida")
    _restore_content()
    http = HTTPRequest.new()
    http.timeout = 15.0
    http.body_size_limit = 96 * 1024
    add_child(http)
    http.request_completed.connect(_on_update_response)
    _show_home()
    print("FRONTERA: menu principal visible (ready)")

func _render_shell() -> void:
    var ground := ColorRect.new()
    ground.color = Color(0.055, 0.108, 0.096)
    ground.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ground.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(ground)
    var stripe := ColorRect.new()
    stripe.color = Color(0.58, 0.35, 0.16)
    stripe.anchor_left = 0.0
    stripe.anchor_right = 1.0
    stripe.anchor_top = 0.0
    stripe.anchor_bottom = 0.0
    stripe.offset_bottom = 7
    stripe.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(stripe)

    var root := VBoxContainer.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 22
    root.offset_right = -22
    root.offset_top = 20
    root.offset_bottom = -20
    root.add_theme_constant_override("separation", 13)
    add_child(root)

    title_label = Label.new()
    title_label.text = "FRONTERA DE FUEGO"
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 42)
    title_label.add_theme_color_override("font_color", Color(0.95, 0.77, 0.48))
    root.add_child(title_label)
    var subtitle := Label.new()
    subtitle.text = "CHILE • LA CONQUISTA • 1541–1598  |  APK BASE " + APP_VERSION
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 17)
    subtitle.add_theme_color_override("font_color", Color(0.77, 0.81, 0.77))
    root.add_child(subtitle)

    var body := HBoxContainer.new()
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_theme_constant_override("separation", 14)
    root.add_child(body)

    menu_panel = _panel()
    menu_panel.custom_minimum_size = Vector2(310, 0)
    body.add_child(menu_panel)
    main_buttons = VBoxContainer.new()
    main_buttons.add_theme_constant_override("separation", 7)
    menu_panel.add_child(main_buttons)
    _menu_button("JUGAR", _show_play)
    _menu_button("MULTIJUGADOR", _show_multiplayer)
    _menu_button("ELEGIR BANDO", _show_sides)
    _menu_button("CAMPAÑA", _show_campaign)
    _menu_button("CONFIGURACIÓN", _show_settings)
    update_button = _menu_button("ACTUALIZAR", _check_updates)
    _menu_button("HISTORIA Y CRÉDITOS", _show_history)
    _menu_button("SALIR", _quit)

    content_panel = _panel()
    content_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body.add_child(content_panel)

    status = Label.new()
    status.text = "Versión base instalada. Los modos jugables se incorporarán mediante actualizaciones verificadas."
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status.add_theme_font_size_override("font_size", 15)
    status.add_theme_color_override("font_color", Color(0.8, 0.87, 0.80))
    root.add_child(status)

func _panel() -> PanelContainer:
    var p := PanelContainer.new()
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.075, 0.16, 0.14, 0.98)
    style.border_color = Color(0.48, 0.34, 0.17)
    style.set_border_width_all(2)
    style.corner_radius_top_left = 9
    style.corner_radius_top_right = 9
    style.corner_radius_bottom_left = 9
    style.corner_radius_bottom_right = 9
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 16
    style.content_margin_bottom = 16
    p.add_theme_stylebox_override("panel", style)
    return p

func _menu_button(label: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = label
    button.custom_minimum_size = Vector2(270, 49)
    button.add_theme_font_size_override("font_size", 18)
    button.pressed.connect(callback)
    main_buttons.add_child(button)
    return button

func _reset_content(headline: String) -> VBoxContainer:
    for child in content_panel.get_children():
        content_panel.remove_child(child)
        child.queue_free()
    var scroll := ScrollContainer.new()
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    content_panel.add_child(scroll)
    var v := VBoxContainer.new()
    v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v.add_theme_constant_override("separation", 13)
    scroll.add_child(v)
    var heading := Label.new()
    heading.text = headline
    heading.add_theme_font_size_override("font_size", 29)
    heading.add_theme_color_override("font_color", Color(0.96, 0.78, 0.47))
    v.add_child(heading)
    return v

func _paragraph(parent: VBoxContainer, txt: String) -> Label:
    var lbl := Label.new()
    lbl.text = txt
    lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    lbl.add_theme_font_size_override("font_size", 19)
    lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    parent.add_child(lbl)
    return lbl

func _action(parent: VBoxContainer, name: String, action: Callable) -> Button:
    var b := Button.new()
    b.text = name
    b.custom_minimum_size.y = 50
    b.add_theme_font_size_override("font_size", 19)
    b.pressed.connect(action)
    parent.add_child(b)
    return b

func _show_home() -> void:
    var v := _reset_content("Frontera de Fuego  •  Base " + APP_VERSION)
    _paragraph(v, "FPS histórico de la Conquista de Chile, con ejércitos españoles y resistencia indígena. Plataforma preparada para recibir mapas, armas y modos multijugador en futuras versiones.")
    _paragraph(v, "Estado: " + ("Paquete jugable cargado (contenido #%d)." % content_version if content_ready else "Base preparada para descargar mapas. Sin combate instalado aún."))
    _paragraph(v, "Bando seleccionado: " + selected_side)
    _paragraph(v, "ACTUALIZAR verifica la firma del canal HTTPS. Los nuevos mapas se descargarán como paquetes PCK; las nuevas APK requieren confirmación de Android.")
    _action(v, "COMPROBAR ACTUALIZACIONES", _check_updates)

func _show_play() -> void:
    if content_ready and ResourceLoader.exists(CONTENT_SCENE):
        var scene: PackedScene = load(CONTENT_SCENE)
        if scene != null:
            get_tree().change_scene_to_packed(scene)
            return
    var v := _reset_content("JUGAR")
    _paragraph(v, "Modo FPS aún no publicado. Esta pantalla quedará reservada para empezar una batalla y reanudar partidas.")
    _paragraph(v, "Primera batalla planificada: Tucapel, 1553. No se mostrarán misiones como disponibles mientras no existan.")
    _action(v, "IR A ACTUALIZAR", _check_updates)

func _show_sides() -> void:
    var v := _reset_content("ELEGIR BANDO")
    _paragraph(v, "La elección se guardará para utilizarla cuando se habiliten los primeros modos de juego.")
    _action(v, "CORONA ESPAÑOLA", func(): _set_side("Corona española"))
    _action(v, "RESISTENCIA MAPUCHE", func(): _set_side("Resistencia mapuche"))
    _paragraph(v, "Selección actual: " + selected_side)

func _set_side(side: String) -> void:
    selected_side = side
    _save_preferences()
    status.text = "Bando elegido: " + side
    _show_sides()

func _show_multiplayer() -> void:
    var v := _reset_content("MULTIJUGADOR")
    _paragraph(v, "El cliente y el servidor de las batallas todavía no están desplegados. Se reservarán aquí las salas, búsqueda de partidas y conexión a servidores ubicados en Chile.")
    _paragraph(v, "No hay servidores disponibles en esta versión. No simularemos conexiones.")
    _paragraph(v, "Primera prueba prevista: 2 jugadores en redes distintas, sincronización de impactos y reconexión.")

func _show_campaign() -> void:
    var v := _reset_content("CAMPAÑA HISTÓRICA")
    for mapname in ["1541 • Defensa de Santiago", "1553 • Tucapel", "1554 • Marigüeñu", "1557 • Mataquito", "1598 • Curalaba"]:
        _paragraph(v, "• " + mapname + "  [PENDIENTE]")
    _paragraph(v, "Las batallas se habilitarán mediante actualizaciones futuras. Las reconstrucciones deberán distinguir hechos documentados de elementos de ficción.")

func _show_settings() -> void:
    var v := _reset_content("CONFIGURACIÓN")
    _paragraph(v, "Idioma: Español de Chile")
    _paragraph(v, "Gráficos: " + selected_quality)
    _action(v, "CALIDAD: BAJA / MEDIA / ALTA", func():
        var opts := ["Baja", "Media", "Alta"]
        selected_quality = opts[(opts.find(selected_quality) + 1) % opts.size()]
        _save_preferences()
        _show_settings())
    _paragraph(v, "Sensibilidad: %.1f" % selected_sensitivity)
    _action(v, "AUMENTAR SENSIBILIDAD", func():
        selected_sensitivity = minf(selected_sensitivity + 0.2, 3.0)
        _save_preferences()
        _show_settings())
    _action(v, "REDUCIR SENSIBILIDAD", func():
        selected_sensitivity = maxf(selected_sensitivity - 0.2, 0.4)
        _save_preferences()
        _show_settings())
    _paragraph(v, "Sonido: " + ("Activado" if selected_music else "Desactivado"))
    _action(v, "CAMBIAR SONIDO", func():
        selected_music = not selected_music
        _save_preferences()
        _show_settings())
    _paragraph(v, "La configuración se conservará entre actualizaciones con la misma identidad Android.")

func _show_history() -> void:
    var v := _reset_content("HISTORIA Y CRÉDITOS")
    _paragraph(v, "Proyecto original FRONTERA DE FUEGO. Inspirado en acontecimientos históricos de Chile durante la Conquista española (siglo XVI).")
    _paragraph(v, "No reproduce material comercial de DOOM ni de otros juegos. Motor: Godot Engine 4.5.1 (licencia MIT).")
    _paragraph(v, "La representación de los pueblos indígenas y las alianzas será investigada y documentada. Los bandos no deben interpretarse como bloques culturales homogéneos.")
    _paragraph(v, "Versión instalada: " + APP_VERSION + " • Paquete: " + APP_PACKAGE)

func _quit() -> void:
    get_tree().quit()

func _load_preferences() -> void:
    var c := ConfigFile.new()
    if c.load("user://preferences.cfg") != OK:
        return
    selected_side = str(c.get_value("player", "side", "Sin seleccionar"))
    selected_quality = str(c.get_value("graphics", "quality", "Media"))
    selected_sensitivity = float(c.get_value("controls", "sensitivity", 1.0))
    selected_music = bool(c.get_value("audio", "enabled", true))

func _save_preferences() -> void:
    var c := ConfigFile.new()
    c.set_value("player", "side", selected_side)
    c.set_value("graphics", "quality", selected_quality)
    c.set_value("controls", "sensitivity", selected_sensitivity)
    c.set_value("audio", "enabled", selected_music)
    var err := c.save("user://preferences.cfg")
    if err != OK:
        status.text = "No se pudieron guardar los ajustes (error %d)." % err

func _check_updates() -> void:
    if update_in_progress:
        return
    update_in_progress = true
    update_phase = "manifest"
    update_button.disabled = true
    status.text = "Consultando canal oficial de actualizaciones..."
    var err := http.request(CHANNEL_URL, PackedStringArray(["Accept: application/json", "Cache-Control: no-cache"]))
    if err != OK:
        _update_done("No se pudo iniciar la consulta de actualizaciones (%d)." % err)

func _on_update_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    if update_phase == "content_download":
        _on_content_download(result, response_code)
        return
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        _update_done("No se pudo consultar el servidor de actualizaciones (HTTP %d)." % response_code)
        return
    if body.size() > 96 * 1024:
        _update_done("Respuesta de actualizaciones demasiado grande.")
        return
    var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
    if not parsed is Dictionary:
        _update_done("La respuesta del servidor no es un manifiesto válido.")
        return
    var manifest: Dictionary = parsed
    var release := _verify_envelope(manifest)
    if release.is_empty():
        _update_done("ALERTA: canal de actualización no válido o firma incorrecta.")
        return
    var version_code := int(release.get("version_code", -1))
    if version_code <= 0:
        _update_done("Versión inválida en el servidor.")
        return
    var content: Variant = release.get("content", {})
    var content_code := 0
    if content is Dictionary:
        content_code = int(content.get("version_code", 0))
    if version_code > APP_CODE:
        var url := str(release.get("apk_url", ""))
        var sha256 := str(release.get("sha256", ""))
        if not _approved_url(url, ".apk") or not _valid_sha256(sha256):
            _update_done("Publicación incorrecta: dirección o huella de APK no válidas.")
            return
        pending_release_url = url
        var v := _reset_content("NUEVA APK DISPONIBLE")
        _paragraph(v, "Nueva versión del programa: %s (código %d)." % [str(release.get("version", "")), version_code])
        _paragraph(v, "Novedades: " + str(release.get("notes", "No especificadas")))
        _paragraph(v, "SHA-256 publicado: " + sha256)
        _paragraph(v, "Android pedirá confirmar la instalación. No desinstales la versión anterior; el paquete y la firma deben coincidir.")
        _action(v, "ABRIR DESCARGA OFICIAL DE APK", _open_update)
        _update_done("Nueva APK disponible. Se descargará desde el navegador.")
        return
    if version_code < APP_CODE:
        # El servidor aún no publicó esta compilación. No inventar el estado "al día".
        status.text = "APK %s instalada. El canal oficial anuncia %s: publicación pendiente." % [APP_VERSION, str(release.get("version", "desconocida"))]
    if content_code > content_version:
        if not content is Dictionary:
            _update_done("No hay datos de contenido válidos.")
            return
        var pack_url := str(content.get("url", ""))
        var pack_hash := str(content.get("sha256", ""))
        var min_app_code := int(content.get("required_app_code", 1))
        if min_app_code > APP_CODE:
            _update_done("El contenido nuevo exige una actualización de la APK.")
            return
        if not _approved_url(pack_url, ".pck") or not _valid_sha256(pack_hash):
            _update_done("Paquete de contenido rechazado: origen o SHA-256 incorrectos.")
            return
        pending_envelope = manifest
        pending_content = content
        _download_content(pack_url, content_code)
        return
    if version_code < APP_CODE:
        _update_done("APK %s instalada. El canal de publicación todavía anuncia %s. No hay descarga nueva." % [APP_VERSION, str(release.get("version", "anterior"))])
        return
    _update_done("FRONTERA DE FUEGO está actualizado. APK %s • Contenido %d." % [APP_VERSION, content_version])

func _approved_url(url: String, suffix: String) -> bool:
    return url.begins_with(TRUSTED_RELEASE_PREFIX) and url.ends_with(suffix) and not url.contains("?")

func _valid_sha256(h: String) -> bool:
    if h.length() != 64:
        return false
    for c in h:
        if not "0123456789abcdef".contains(c):
            return false
    return true

func _verify_envelope(envelope: Dictionary) -> Dictionary:
    if not envelope.has("payload") or not envelope.has("signature"):
        return {}
    if not FileAccess.file_exists("res://assets/update_public.pem"):
        push_error("FRONTERA: clave publica de actualizaciones no incluida en exportacion")
        return {}
    var payload := str(envelope["payload"])
    var signature := Marshalls.base64_to_raw(str(envelope["signature"]))
    var key := CryptoKey.new()
    if key.load_from_string(FileAccess.get_file_as_string("res://assets/update_public.pem"), true) != OK:
        return {}
    if not Crypto.new().verify(HashingContext.HASH_SHA256, payload.sha256_buffer(), signature, key):
        return {}
    var decoded: Variant = JSON.parse_string(payload)
    if not decoded is Dictionary:
        return {}
    if str(decoded.get("package", "")) != APP_PACKAGE:
        return {}
    return decoded

func _content_path(code: int) -> String:
    return CONTENT_DIR.path_join(CONTENT_PREFIX + str(code) + ".pck")

func _restore_content() -> void:
    if not FileAccess.file_exists(CONTENT_META):
        return
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(CONTENT_META))
    if not parsed is Dictionary:
        return
    var data := _verify_envelope(parsed)
    if data.is_empty():
        return
    var content: Variant = data.get("content", {})
    if not content is Dictionary:
        return
    var code := int(content.get("version_code", 0))
    var pack := _content_path(code)
    var digest := str(content.get("sha256", ""))
    if code <= 0 or not _valid_sha256(digest) or not FileAccess.file_exists(pack):
        return
    if FileAccess.get_sha256(pack) != digest:
        return
    if ProjectSettings.load_resource_pack(pack, false):
        content_version = code
        content_ready = ResourceLoader.exists(CONTENT_SCENE)

func _download_content(url: String, code: int) -> void:
    var real_dir := ProjectSettings.globalize_path(CONTENT_DIR)
    if DirAccess.make_dir_recursive_absolute(real_dir) != OK:
        _update_done("No se pudo preparar almacenamiento de contenidos.")
        return
    incoming_pack_path = CONTENT_DIR.path_join("download_%d.tmp" % code)
    http.download_file = incoming_pack_path
    # Impedir descargas ilimitadas en celulares con almacenamiento escaso.
    http.body_size_limit = MAX_CONTENT_BYTES
    update_phase = "content_download"
    status.text = "Descargando contenido histórico versión %d..." % code
    var err := http.request(url)
    if err != OK:
        http.download_file = ""
        http.body_size_limit = 96 * 1024
        _update_done("No se pudo comenzar la descarga del contenido (%d)." % err)

func _on_content_download(result: int, response_code: int) -> void:
    http.download_file = ""
    http.body_size_limit = 96 * 1024
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        _discard_partial_download()
        _update_done("La descarga de contenido falló (HTTP %d). Se mantiene versión anterior." % response_code)
        return
    var expected := str(pending_content.get("sha256", ""))
    var code := int(pending_content.get("version_code", 0))
    if not FileAccess.file_exists(incoming_pack_path) or FileAccess.get_sha256(incoming_pack_path) != expected:
        _discard_partial_download()
        _update_done("SHA-256 incorrecto. Paquete descartado y versión anterior conservada.")
        return
    var destination := _content_path(code)
    var rename_err := DirAccess.rename_absolute(ProjectSettings.globalize_path(incoming_pack_path), ProjectSettings.globalize_path(destination))
    if rename_err != OK:
        _discard_partial_download()
        _update_done("No se pudo guardar el paquete (%d). Versión anterior conservada." % rename_err)
        return
    var output := FileAccess.open(CONTENT_META + ".tmp", FileAccess.WRITE)
    if output == null:
        _update_done("No se pudo registrar el paquete. Se conserva la versión anterior.")
        return
    output.store_string(JSON.stringify(pending_envelope))
    output.flush()
    output.close()
    if DirAccess.rename_absolute(ProjectSettings.globalize_path(CONTENT_META + ".tmp"), ProjectSettings.globalize_path(CONTENT_META)) != OK:
        _update_done("No se pudo activar el contenido. Se conserva la versión anterior.")
        return
    incoming_pack_path = ""
    _update_done("Contenido %d descargado y verificado. Cierra y vuelve a abrir el juego para activarlo." % code)

func _discard_partial_download() -> void:
    if incoming_pack_path != "" and FileAccess.file_exists(incoming_pack_path):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(incoming_pack_path))
    incoming_pack_path = ""

func _open_update() -> void:
    if not _approved_url(pending_release_url, ".apk"):
        status.text = "La dirección de descarga no es confiable."
        return
    var err := OS.shell_open(pending_release_url)
    if err != OK:
        status.text = "No se pudo abrir el navegador (%d)." % err
    else:
        status.text = "Descarga abierta. Android solicitará confirmar la actualización después de descargar la APK."

func _update_done(message: String) -> void:
    update_in_progress = false
    update_phase = "idle"
    update_button.disabled = false
    status.text = message
