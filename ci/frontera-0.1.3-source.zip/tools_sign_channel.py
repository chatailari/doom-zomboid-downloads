#!/usr/bin/env python3
# This script runs OFFLINE. The private key must never be committed to GitHub.
import argparse, base64, hashlib, json
from pathlib import Path
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
parser=argparse.ArgumentParser()
parser.add_argument('--key',required=True)
parser.add_argument('--package',default='cl.nazaret.fronteradefuego')
parser.add_argument('--version',required=True)
parser.add_argument('--version-code',required=True,type=int)
parser.add_argument('--apk',required=True)
parser.add_argument('--url',required=True)
parser.add_argument('--notes',default='Actualización de Frontera de Fuego')
parser.add_argument('--output',default='releases/channel.json')
a=parser.parse_args()
if not a.url.startswith('https://github.com/chatailari/doom-zomboid-downloads/releases/download/frontera-v') or not a.url.endswith('.apk'):
    raise SystemExit('URL de APK no está en el origen autorizado.')
if not Path(a.apk).is_file():
    raise SystemExit('APK no existe.')
payload=json.dumps({'package':a.package,'version_code':a.version_code,'version':a.version,'apk_url':a.url,'sha256':hashlib.sha256(Path(a.apk).read_bytes()).hexdigest(),'notes':a.notes},ensure_ascii=False,separators=(',',':'))
key=serialization.load_pem_private_key(Path(a.key).read_bytes(),password=None)
signature=key.sign(hashlib.sha256(payload.encode()).digest(),padding.PKCS1v15(),Prehashed(hashes.SHA256()))
Path(a.output).write_text(json.dumps({'payload':payload,'signature':base64.b64encode(signature).decode('ascii')},indent=2,ensure_ascii=False)+'\n')
print('Manifiesto firmado',a.output)
