#!/usr/bin/env python3
"""Pruebas offline de continuidad de la base, no ejecuta Godot."""
import re
from pathlib import Path
from unittest import TestCase, main

BASE=Path(__file__).resolve().parent
class Continuidad(TestCase):
    def test_version_y_paquete(self):
        code=(BASE/'scripts/menu.gd').read_text()
        preset=(BASE/'export_presets.cfg').read_text()
        self.assertIn('const APP_VERSION := "0.1.3"',code)
        self.assertIn('const APP_CODE := 4',code)
        self.assertIn('package/unique_name="cl.nazaret.fronteradefuego"',preset)
        self.assertIn('version/code=4',preset)
        self.assertIn('version/name="0.1.3"',preset)
    def test_pem_canal_en_exportacion(self):
        preset=(BASE/'export_presets.cfg').read_text()
        self.assertIn('assets/*.pem',preset)
        self.assertTrue((BASE/'assets/update_public.pem').exists())
        self.assertIn('releases/*.json',preset)
    def test_estado_definido(self):
        code=(BASE/'scripts/menu.gd').read_text()
        for field in ['content_ready','content_version','update_phase','pending_envelope','pending_content','incoming_pack_path']:
            self.assertRegex(code,rf'var {field}\b')
    def test_no_claves_privadas_en_proyecto(self):
        for p in BASE.rglob('*'):
            if not p.is_file(): continue
            self.assertNotIn(p.suffix.lower(),['.p12','.pfx','.keystore','.jks','.key'],str(p))
            if p.suffix.lower() in ['.pem','.md','.txt','.gd','.json','.yml','.cfg','.py']:
                self.assertNotIn('BEGIN ' + 'PRIVATE KEY',p.read_text(errors='replace'),str(p))
                self.assertNotIn('BEGIN RSA ' + 'PRIVATE KEY',p.read_text(errors='replace'),str(p))
    def test_no_publicacion_automatica(self):
        content=(BASE/'releases/channel.json').read_text()
        self.assertIn('"signature"',content)
        self.assertIn('"payload"',content)
        self.assertIn('v0.1.0', (BASE/'README.md').read_text().replace('0.1.0', 'v0.1.0'))
    def test_registro_de_arranque(self):
        code=(BASE/'scripts/menu.gd').read_text()
        self.assertIn('FRONTERA: menu principal visible (ready)',code)
        self.assertIn('FRONTERA: interfaz construida',code)

if __name__=='__main__':main(verbosity=2)
