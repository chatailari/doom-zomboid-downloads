import sys
import tempfile
import unittest
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from release_channel import make_payload,sign,verify,trusted_release_url

PREFIX='https://github.com/example/releases/download/app-v'

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)
        self.apk=self.path/'one.apk';self.apk.write_bytes(b'APK test data only')
        self.pck=self.path/'one.pck';self.pck.write_bytes(b'PCK test data only')
        self.key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        self.private=self.path/'private.key'; self.public=self.path/'public.pem'
        self.private.write_bytes(self.key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        self.public.write_bytes(self.key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))
    def data(self,**kw):
        base=dict(package='cl.example.application',app_code=4,version='0.1.3',apk_file=self.apk,apk_url=PREFIX+'0.1.3/one.apk',release_prefix=PREFIX)
        base.update(kw)
        return make_payload(**base)
    def test_apk_only(self):
        d=self.data()
        e=sign(d,self.private)
        self.assertEqual(verify(e,self.public,'cl.example.application'),d)
        self.assertEqual(d['content']['version_code'],0)
    def test_apk_and_game_content(self):
        d=self.data(content_code=7,content_file=self.pck,content_url=PREFIX+'0.1.3/one.pck',required_app_code=3)
        self.assertEqual(d['content']['version_code'],7)
        self.assertEqual(verify(sign(d,self.private),self.public,'cl.example.application'),d)
    def test_forgery_rejected(self):
        e=sign(self.data(),self.private)
        e['payload']=e['payload'].replace('0.1.3','9.9.9')
        with self.assertRaises(Exception):verify(e,self.public,'cl.example.application')
    def test_cross_app_rejected(self):
        with self.assertRaises(ValueError):verify(sign(self.data(),self.private),self.public,'cl.other.app')
    def test_http_rejected(self):
        with self.assertRaises(ValueError):self.data(apk_url='http://github.com/example/releases/download/app-v0.1.3/one.apk')
    def test_external_domain_rejected(self):
        with self.assertRaises(ValueError):self.data(apk_url='https://github.com.evil.example/releases/download/app-v0.1.3/one.apk')
    def test_query_param_rejected(self):
        with self.assertRaises(ValueError):self.data(apk_url=PREFIX+'0.1.3/one.apk?unsafe=1')
    def test_content_requires_file(self):
        with self.assertRaises(ValueError):self.data(content_code=7,content_url=PREFIX+'0.1.3/one.pck')
    def test_no_implicit_content(self):
        with self.assertRaises(ValueError):self.data(content_file=self.pck)
    def test_invalid_version_rejected(self):
        with self.assertRaises(ValueError):self.data(app_code=-1)

if __name__=='__main__':unittest.main()
