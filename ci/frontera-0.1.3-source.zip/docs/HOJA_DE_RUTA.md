# Contrato de no regresión y entrega

1. Aislar código de este juego y preservar DOOM-ZOMBOID / DOOM REBORN intactos.
2. Obtener APK 0.1.0 instalable con certificado de firma estable; registrar huella de certificado y SHA256 del archivo.
3. Validar menú, persistencia tras cierre y apertura, y respuesta del canal de actualizaciones.
4. Publicar APK en GitHub Releases separado; confirmar URL accesible sin inicio de sesión.
5. Publicar v0.1.1 firmada con mismo certificado y manifiesto digital verificado. Probar actualización tocando botón ACTUALIZAR en un Android real.
6. No declarar sistema completo hasta completar el paso 5.
7. En hitos futuros: crear escenario Tucapel, combate FPS, armas históricas, 2 jugadores, servidor chileno y pruebas de latencia.
