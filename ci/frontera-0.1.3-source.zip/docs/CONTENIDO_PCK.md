# Paquetes incrementales PCK

El botón ACTUALIZAR lee el canal público firmado por RSA. Si existe contenido nuevo compatible con el código de la APK instalada, descarga un `.pck` exclusivo de las versiones `frontera-v*`, verifica su SHA-256 y guarda el manifiesto firmado y el archivo en `user://content/`.

Al siguiente inicio, el juego vuelve a verificar la firma RSA y el SHA-256; solo entonces monta el PCK con `ProjectSettings.load_resource_pack(path,false)`. No debe reemplazarse el menú o la configuración base. El recurso nuevo debe contener `res://content/start.tscn`, escena que JUGAR abre si está presente.

**ATENCIÓN**: este flujo está implementado en fuente, pero no se ha validado contra una APK Android ni una publicación PCK real.

Los cambios de permisos, paquetes, motor, Android nativo y funciones de la APK requieren nueva APK firmada con la MISMA clave original.
