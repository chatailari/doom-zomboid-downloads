# FRONTERA DE FUEGO — Android base 0.1.0

Proyecto independiente en Godot 4.5.1 para la futura campaña FPS de la Conquista de Chile. NO modifica DOOM-ZOMBOID ni DOOM REBORN.

## Funciones de la base
- Menú de bienvenida, jugar (pendiente), multijugador (pendiente), selección de bando, campaña (pendiente), configuración persistente, historia/créditos y salir.
- Actualizador por HTTPS: comprueba la firma RSA del manifiesto, compara versiones de APK y de contenido. Puede descargar contenido `.pck`, verificar SHA-256, guardar la versión y cargarla tras reiniciar; cuando se necesita una APK, abre la descarga oficial en el navegador Android.
- Android comprueba la firma del APK al instalar sobre una aplicación ya existente. El usuario debe aprobar manualmente la instalación. La verificación de SHA-256 *del propio APK descargado* y la instalación interna por FileProvider aún NO están implementadas: el navegador descarga la APK oficial y Android valida su certificado de firma al instalar.
- Los futuros paquetes de contenido deben añadir `res://content/start.tscn`, con sus recursos y scripts; se cargan al pulsar JUGAR. La base no contiene combate ni servidor online. No se presenta como videojuego terminado.

## Identidades fijas
- Paquete: `cl.nazaret.fronteradefuego`
- Primera versión: `0.1.0`, código `1`
- Canal: `https://raw.githubusercontent.com/chatailari/doom-zomboid-downloads/main/frontera-de-fuego/channel.json`
- APK futura en release `frontera-vX.Y.Z` del repositorio de distribuciones. Canal y APK independientes de DOOM-ZOMBOID aunque compartan proveedor GitHub.

## Compilación
Necesita Godot 4.5.1 estable, las plantillas de exportación Android de la misma versión, OpenJDK 17 y Android SDK 35 con build-tools 35.0.0.

`godot --headless --path . --editor --quit`

`GODOT_ANDROID_KEYSTORE_RELEASE_PATH=/ruta/clave.keystore GODOT_ANDROID_KEYSTORE_RELEASE_USER=frontera GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD=... godot --headless --path . --export-release 'Android ARM64' build/FRONTERA-DE-FUEGO-0.1.0-arm64.apk`

**IMPORTANTE:** conservar siempre la misma clave Android de firma. La clave privada de actualización tampoco debe colocarse en GitHub. En CI deben usarse secretos. Versiones sucesivas deben aumentar `version/code` y conservar `package/unique_name`.

## Estado de verificación
- Fuente y manifiesto estructurados y comprobados con validaciones locales Python.
- No se ha compilado ni ejecutado una APK en esta sesión. Esta máquina no dispone de Godot ni Android SDK y el acceso remoto está bloqueado por límite de uso. Se requieren pruebas reales antes de declarar instalación y botón ACTUALIZAR terminados.
- Para una prueba completa de actualización publicar `v0.1.1` con la misma firma; instalar 0.1.0, pulsar ACTUALIZAR, instalar sobre 0.1.0 y comprobar ajustes persistentes.


> CONTINUIDAD: esta carpeta fue actualizada a la fuente candidata 0.1.2 a partir del respaldo 0.1.0. Ver RECUPERACION_0.1.2.md; no declarar la APK 0.1.2 existente sin exportar y probar.
