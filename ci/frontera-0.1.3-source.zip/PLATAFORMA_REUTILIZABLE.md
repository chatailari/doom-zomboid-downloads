# Plataforma reutilizable para aplicaciones y juegos Android (base Godot 4.5.1)

## Límites reales del producto

La APK de FRONTERA DE FUEGO es una base de **su misma aplicación**: conserva package ID `cl.nazaret.fronteradefuego`, el certificado Android histórico y su archivo local `user://`. El canal RSA firmado puede anunciar una nueva APK completa (cambios en la aplicación) o un `.pck` (contenido del juego). Son dos procesos diferentes.

El botón **ACTUALIZAR** comprueba el canal HTTPS `frontera-de-fuego/channel.json`, verifica la firma RSA y compara `version_code` de APK y de contenido. Una APK nueva abre la descarga oficial en el navegador y Android solicita instalarla con intervención del usuario; un PCK compatible se descarga y comprueba con SHA-256 y se monta al siguiente inicio. Las APK NO son parches diferenciales de bytes. Android debe validar paquete y firma y la instalación puede requerir confirmación.

## Para otros juegos o aplicaciones

Se reutilizan los componentes fuente y las pruebas, pero **no** el mismo APK binario como si fuera cualquier app: cada app autónoma requiere un ID de paquete propio, su certificado privado estable, nombre, icono, permisos, manifiesto firmado y canal de distribución independiente. Una alternativa es mantener experiencias independientes dentro del *mismo hub Godot*, mediante escenas PCK compatibles, sin crear apps Android autónomas. Los cambios nativos/permisos requieren siempre nueva APK.

No abrir canales públicos sin Release disponible, firma verificada y SHA real. No publicar ni subir al repositorio ZIP de claves privadas, p12, contraseñas o PEM privados.

## Estado de esta fuente

La fuente candidata 0.1.2 se recuperó desde 0.1.0; la APK 0.1.2 candidata entregada en chat es una **reparación conservadora de la APK 0.1.1**, no una compilación de estos mismos fuentes. La correspondencia exacta de código fuente con APK no está certificada. Validación de compilación Godot y prueba Android física pendientes.

## Receta de distribución futura

1. Compilar versión 0.1.3 con Godot y export templates, `version/code=4`, misma identidad y mismo keystore privado, exportación `gl_compatibility` con PEM incluido.
2. Probar UI real Android, descargar PCK de prueba, restaurar y abrir contenido. Probar instalación por encima de la versión 0.1.2 sin desinstalar y sin perder preferencias/partidas.
3. Auditar con `apksigner verify --verbose --print-certs`, cotejar certificado SHA-256 original, revisar ZIP/sparse PCK, `aapt dump badging`, logs de `adb logcat` y capturas.
4. Subir APK/PCK a Release **real** y comprobar la URL por HTTPS y tamaño/hash.
5. Usar `tools/release_channel.py` fuera del repositorio con la clave RSA privada; firma todo el `payload` con PKCS#1 v1.5 SHA-256; verificar con PEM público. **No publicar el manifiesto hasta existir la APK descargable.**
6. Publicar mediante un commit atómico el nuevo `frontera-de-fuego/channel.json`. El botón ACTUALIZAR detectará la versión si la app pasa las pruebas Android.

## Criterio de finalización

Un APK está *validado* solo tras instalación y reapertura en Android compatible, menús visibles sin pantalla gris, botón ACTUALIZAR comprobado desde el dispositivo con dos versiones sucesivas y preservación de datos. Las pruebas estáticas y criptográficas por sí solas no certifican esos requisitos.
